// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.9.0" apply false
    id("org.jetbrains.kotlin.android") version "1.8.21" apply false
    id("com.android.library") version "8.3.0" apply false
    // Firebase (Google Services plugin)
        id("com.google.gms.google-services") version "4.4.0" apply false
        // Add other plugins (e.g., Crashlytics, Performance Monitoring) if needed
    }


// Optional: Define common variables for versions (if needed)
val compileSdkVersion by extra(34)
val minSdkVersion by extra(24)
val targetSdkVersion by extra(34)