package com.example.lostfoundtracker;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.List;

public class BrowseFoundActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TextView emptyView;
    private SwipeRefreshLayout swipeRefresh;
    private EditText searchBar;
    private ItemAdapter adapter;
    private FirebaseFirestore db;
    private List<LostItem> itemList;
    private List<LostItem> filteredList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_found);

        db = FirebaseFirestore.getInstance();
        db.enableNetwork().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                Toast.makeText(this, "Offline mode enabled", Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView = findViewById(R.id.recyclerView);
        emptyView = findViewById(R.id.emptyView);
        swipeRefresh = findViewById(R.id.swipeRefresh);
        searchBar = findViewById(R.id.searchBar);

        itemList = new ArrayList<>();
        filteredList = new ArrayList<>();
        adapter = new ItemAdapter(filteredList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                filterItems(s.toString());
            }
        });

        swipeRefresh.setOnRefreshListener(this::loadLostItems);
        loadLostItems();
    }

    private void loadLostItems() {
        swipeRefresh.setRefreshing(true);

        db.collection("lost_items")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    swipeRefresh.setRefreshing(false);

                    if (task.isSuccessful()) {
                        itemList.clear();
                        for (DocumentSnapshot doc : task.getResult()) {
                            LostItem item = doc.toObject(LostItem.class);
                            if (item != null) {
                                item.setId(doc.getId());
                                itemList.add(item);
                            }
                        }
                        filterItems(searchBar.getText().toString());
                    } else {
                        Toast.makeText(this, "Error loading items: " +
                                        (task.getException() != null ?
                                                task.getException().getMessage() : "Unknown error"),
                                Toast.LENGTH_SHORT).show();
                    }
                    checkEmptyState();
                });
    }

    private void filterItems(String query) {
        filteredList.clear();

        if (query.isEmpty()) {
            filteredList.addAll(itemList);
        } else {
            String lowerCaseQuery = query.toLowerCase();
            for (LostItem item : itemList) {
                if ((item.getName() != null && item.getName().toLowerCase().contains(lowerCaseQuery)) ||
                        (item.getDescription() != null && item.getDescription().toLowerCase().contains(lowerCaseQuery)) ||
                        (item.getLocation() != null && item.getLocation().toLowerCase().contains(lowerCaseQuery))) {
                    filteredList.add(item);
                }
            }
        }

        adapter.notifyDataSetChanged();
        checkEmptyState();
    }

    private void checkEmptyState() {
        if (filteredList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
        }
    }
}