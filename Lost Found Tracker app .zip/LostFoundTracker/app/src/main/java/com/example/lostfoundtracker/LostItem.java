package com.example.lostfoundtracker;

import com.google.firebase.firestore.DocumentId;
import com.google.firebase.firestore.ServerTimestamp;
import java.util.Date;

public class LostItem {
    @DocumentId
    private String id;
    private String name;
    private String description;
    private String location;
    private String imageUrl;
    private String userId;
    private String status;      // "lost" or "found"
    private String contactInfo; // phone/email for contact
    private String category;    // item category

    @ServerTimestamp
    private Date timestamp;

    public LostItem() {}

    public LostItem(String name, String description, String location) {
        this.name = name;
        this.description = description;
        this.location = location;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getContactInfo() { return contactInfo; }
    public void setContactInfo(String contactInfo) { this.contactInfo = contactInfo; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getFormattedTime() {
        if (timestamp != null) {
            return android.text.format.DateFormat.format("MMM dd, yyyy hh:mm a", timestamp).toString();
        }
        return "Date not available";
    }
}