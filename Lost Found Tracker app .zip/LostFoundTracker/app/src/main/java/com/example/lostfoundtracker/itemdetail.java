package com.example.lostfoundtracker;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class itemdetail extends AppCompatActivity {

    private ImageView itemImage;
    private TextView itemName, itemDescription, itemLocation, itemDate, itemUser;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itemdetail);

        // Initialize views
        itemImage = findViewById(R.id.item_detail_image);
        itemName = findViewById(R.id.item_detail_name);
        itemDescription = findViewById(R.id.item_detail_description);
        itemLocation = findViewById(R.id.item_detail_location);
        itemDate = findViewById(R.id.item_detail_date);
        itemUser = findViewById(R.id.item_detail_user);

        db = FirebaseFirestore.getInstance();

        // Get item ID from intent
        String itemId = getIntent().getStringExtra("item_id");
        if (itemId != null) {
            loadItemDetails(itemId);
        } else {
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void loadItemDetails(String itemId) {
        db.collection("lost_items").document(itemId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            LostItem item = document.toObject(LostItem.class);
                            if (item != null) {
                                displayItemDetails(item);
                            }
                        } else {
                            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    } else {
                        Toast.makeText(this, "Error loading item", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }

    private void displayItemDetails(LostItem item) {
        itemName.setText(item.getName());
        itemDescription.setText(item.getDescription());
        itemLocation.setText("Location: " + item.getLocation());
        itemDate.setText("Reported on: " + item.getFormattedTime());

        // Load user information if available
        if (item.getUserId() != null) {
            db.collection("users").document(item.getUserId())
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            String username = documentSnapshot.getString("name");
                            itemUser.setText("Reported by: " + (username != null ? username : "Anonymous"));
                        } else {
                            itemUser.setText("Reported by: Anonymous");
                        }
                    });
        } else {
            itemUser.setText("Reported by: Anonymous");
        }

        // Reset ImageView state
        itemImage.setBackgroundColor(Color.TRANSPARENT);

        // Load image with improved handling
        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
            Glide.with(this)
                    .load(item.getImageUrl())
                    .into(itemImage);
        } else {
            // Option 1: Show colored background
            itemImage.setBackgroundColor(Color.parseColor("#F5F5F5")); // Light gray
            itemImage.setImageResource(android.R.color.transparent);

            // OR Option 2: Hide the ImageView completely
            // itemImage.setVisibility(View.GONE);
        }
    }
}