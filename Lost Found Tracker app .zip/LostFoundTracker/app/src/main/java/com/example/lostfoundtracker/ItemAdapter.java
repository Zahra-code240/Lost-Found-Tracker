package com.example.lostfoundtracker;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private final List<LostItem> itemList;
    private OnItemClickListener listener;
    private final StorageReference storageRef;

    public ItemAdapter(List<LostItem> itemList) {
        this.itemList = itemList;
        this.storageRef = FirebaseStorage.getInstance().getReference("lost_items_images");
    }

    public interface OnItemClickListener {
        void onItemClick(LostItem item);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LostItem item = itemList.get(position);
        holder.bind(item);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView itemImage;
        private final TextView textName;
        private final TextView textDescription;
        private final TextView textLocation;
        private final TextView textTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImage = itemView.findViewById(R.id.itemImage);
            textName = itemView.findViewById(R.id.textName);
            textDescription = itemView.findViewById(R.id.textDescription);
            textLocation = itemView.findViewById(R.id.textLocation);
            textTime = itemView.findViewById(R.id.textTime);
        }

        public void bind(LostItem item) {
            textName.setText(item.getName());
            textDescription.setText(item.getDescription());
            textLocation.setText("Location: " + item.getLocation());
            textTime.setText("Posted: " + item.getFormattedTime());

            // Reset ImageView state
            itemImage.setVisibility(View.VISIBLE);
            itemImage.setBackgroundColor(Color.TRANSPARENT);

            if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
                // Load from Firebase Storage
                if (item.getImageUrl().startsWith("gs://")) {
                    // Direct Storage reference
                    StorageReference imageRef = FirebaseStorage.getInstance()
                            .getReferenceFromUrl(item.getImageUrl());
                    loadFirebaseImage(imageRef);
                } else if (item.getImageUrl().startsWith("http")) {
                    // Download URL
                    Glide.with(itemView.getContext())
                            .load(item.getImageUrl())
                            .into(itemImage);
                }
            } else {
                // No image - show placeholder
                itemImage.setBackgroundColor(Color.parseColor("#F5F5F5"));
                itemImage.setImageResource(android.R.color.transparent);
            }
        }

        private void loadFirebaseImage(StorageReference imageRef) {
            imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                Glide.with(itemView.getContext())
                        .load(uri)
                        .into(itemImage);
            }).addOnFailureListener(e -> {
                itemImage.setBackgroundColor(Color.parseColor("#FFEBEE")); // Light red
                itemImage.setImageResource(android.R.drawable.ic_menu_report_image);
            });
        }
    }
}