package com.example.lostfoundtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private RecyclerView recyclerView;
    private ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load lost items from Firestore
        loadLostItems();

        Button btnReportLost = findViewById(R.id.btnReportLost);
        Button btnBrowseFound = findViewById(R.id.btnBrowseFound);
        Button btnMyItems = findViewById(R.id.btnMyItems);
        Button btnLogout = findViewById(R.id.btnLogout);

        btnReportLost.setOnClickListener(v ->
                startActivity(new Intent(this, ReportLostActivity.class)));

        btnBrowseFound.setOnClickListener(v ->
                startActivity(new Intent(this, BrowseFoundActivity.class)));

        btnMyItems.setOnClickListener(v ->
                startActivity(new Intent(this, MyItemsActivity.class)));

        btnLogout.setOnClickListener(v -> showLogoutConfirmation());
    }

    private void loadLostItems() {
        db.collection("lost_items")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Toast.makeText(this, "Error loading items", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (value != null) {
                        List<LostItem> items = value.toObjects(LostItem.class);
                        adapter = new ItemAdapter(items);
                        recyclerView.setAdapter(adapter);
                    }
                });
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || !currentUser.isEmailVerified()) {
            redirectToLogin();
        }
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    mAuth.signOut();
                    Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                    redirectToLogin();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void redirectToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}