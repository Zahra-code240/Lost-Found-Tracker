package com.example.lostfoundtracker;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.List;

public class MyItemsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private List<LostItem> myItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_items);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(myItems);
        recyclerView.setAdapter(adapter);

        loadUserItems();
    }

    private void loadUserItems() {
        String userId = mAuth.getCurrentUser() != null ? mAuth.getCurrentUser().getUid() : null;
        if (userId == null) {
            Toast.makeText(this, "Not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        db.collection("lost_items")
                .whereEqualTo("userId", userId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        myItems.clear();
                        for (DocumentSnapshot doc : task.getResult()) {
                            LostItem item = doc.toObject(LostItem.class);
                            if (item != null) {
                                item.setId(doc.getId());  // Make sure LostItem has setId() method
                                myItems.add(item);
                            }
                        }
                        adapter.notifyDataSetChanged();

                        if (myItems.isEmpty()) {
                            Toast.makeText(this, "You haven't posted any items yet", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Error loading items: " + task.getException(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}